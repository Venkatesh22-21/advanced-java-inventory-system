# Advanced Java: Inventory & Ordering System (Console)

This is a simple, self-contained **Java console application** that demonstrates intermediate Java skills:
- Object-oriented design (classes, encapsulation)
- Collections (ArrayList, Map)
- File-based persistence (CSV)
- Exception handling
- Basic input validation
- Modular code structure

## Files
- Product.java
- Inventory.java
- OrderItem.java
- Order.java
- OrderManager.java
- Main.java

## How to compile & run (using command line)
1. Open terminal in this project folder.
2. Compile:
   ```
   javac *.java
   ```
3. Run:
   ```
   java Main
   ```

The app stores products in `products.csv` and orders in `orders.csv` in the same folder.
