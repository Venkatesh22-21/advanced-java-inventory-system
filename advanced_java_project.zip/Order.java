import java.util.*;
public class Order {
    private static int counter = 1000;
    private String orderId;
    private String customerName;
    private List<OrderItem> items = new ArrayList<>();
    private Date createdAt;

    public Order(String customerName) {
        this.orderId = "ORD" + (++counter);
        this.customerName = customerName;
        this.createdAt = new Date();
    }

    public void addItem(OrderItem it) { items.add(it); }

    public double getTotal() {
        double t = 0;
        for (OrderItem it : items) t += it.getTotal();
        return t;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Order: ").append(orderId).append(" | Customer: ").append(customerName).append("\n");
        for (OrderItem it : items) sb.append("  - ").append(it.toString()).append("\n");
        sb.append("Total: ₹").append(getTotal());
        return sb.toString();
    }

    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(orderId).append(",").append(customerName.replace(","," ")).append(",").append(createdAt.getTime()).append(",");
        List<String> its = new ArrayList<>();
        for (OrderItem it : items) its.add(it.toCSV());
        sb.append(String.join("|", its));
        return sb.toString();
    }

    public static Order fromCSV(String line) {
        try {
            String[] parts = line.split(",", 4);
            if (parts.length < 4) return null;
            Order o = new Order(parts[1]);
            // override generated id and date
            o.orderId = parts[0];
            o.createdAt = new Date(Long.parseLong(parts[2]));
            String itemsPart = parts[3];
            String[] its = itemsPart.split("\|");
            for (String s : its) {
                OrderItem it = OrderItem.fromCSV(s);
                if (it != null) o.addItem(it);
            }
            return o;
        } catch (Exception e) {
            return null;
        }
    }
}
