public class OrderItem {
    private String sku;
    private String name;
    private int qty;
    private double unitPrice;

    public OrderItem(String sku, String name, int qty, double unitPrice) {
        this.sku = sku;
        this.name = name;
        this.qty = qty;
        this.unitPrice = unitPrice;
    }

    public double getTotal() {
        return qty * unitPrice;
    }

    @Override
    public String toString() {
        return name + " (" + sku + ") x" + qty + " => ₹" + getTotal();
    }

    public String toCSV() {
        return sku + ";" + name.replace(";", " ") + ";" + qty + ";" + unitPrice;
    }

    public static OrderItem fromCSV(String s) {
        String[] parts = s.split(";");
        if (parts.length < 4) return null;
        return new OrderItem(parts[0], parts[1], Integer.parseInt(parts[2]), Double.parseDouble(parts[3]));
    }
}
