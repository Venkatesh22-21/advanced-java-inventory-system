import java.io.*;
import java.util.*;
public class OrderManager {
    private List<Order> orders = new ArrayList<>();
    private File file;

    public OrderManager(String filepath) {
        this.file = new File(filepath);
        load();
    }

    public void placeOrder(Order o) {
        orders.add(o);
        save();
    }

    public List<Order> listOrders() {
        return orders;
    }

    public void save() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(file, false))) {
            for (Order o : orders) {
                pw.println(o.toCSV());
            }
        } catch (Exception e) {
            System.out.println("Failed to save orders: " + e.getMessage());
        }
    }

    public void load() {
        orders.clear();
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                Order o = Order.fromCSV(line);
                if (o != null) orders.add(o);
            }
        } catch (Exception e) {
            System.out.println("Failed to load orders: " + e.getMessage());
        }
    }
}
