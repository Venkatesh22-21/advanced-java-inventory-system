import java.util.*;
public class Main {
    private static Inventory inv = new Inventory("products.csv");
    private static OrderManager om = new OrderManager("orders.csv");
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        seedIfEmpty();
        while (true) {
            System.out.println("\n=== Bakery Inventory & Ordering ===");
            System.out.println("1. List Products");
            System.out.println("2. Add Product (admin)");
            System.out.println("3. Place Order");
            System.out.println("4. View Orders");
            System.out.println("5. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine();
            try {
                switch (choice) {
                    case "1": listProducts(); break;
                    case "2": addProduct(); break;
                    case "3": placeOrder(); break;
                    case "4": viewOrders(); break;
                    case "5": System.out.println("Bye!"); return;
                    default: System.out.println("Invalid choice");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void seedIfEmpty() {
        if (!inv.listProducts().iterator().hasNext()) {
            inv.addProduct(new Product("B001","Chocolate Cake",499.0,10));
            inv.addProduct(new Product("B002","Butter Croissant",60.0,50));
            inv.addProduct(new Product("B003","Blueberry Muffin",80.0,40));
        }
    }

    private static void listProducts() {
        System.out.println("\nAvailable Products:");
        for (Product p : inv.listProducts()) {
            System.out.println(p.toString());
        }
    }

    private static void addProduct() {
        System.out.print("Enter SKU: "); String sku = sc.nextLine().trim();
        System.out.print("Name: "); String name = sc.nextLine().trim();
        System.out.print("Price: "); double price = Double.parseDouble(sc.nextLine().trim());
        System.out.print("Stock: "); int stock = Integer.parseInt(sc.nextLine().trim());
        inv.addProduct(new Product(sku, name, price, stock));
        System.out.println("Product added.");
    }

    private static void placeOrder() {
        System.out.print("Customer name: "); String cname = sc.nextLine().trim();
        Order o = new Order(cname);
        while (true) {
            System.out.print("Enter product SKU (or 'done'): ");
            String sku = sc.nextLine().trim();
            if (sku.equalsIgnoreCase("done")) break;
            Product p = inv.getProduct(sku);
            if (p == null) {
                System.out.println("SKU not found."); continue;
            }
            System.out.print("Quantity: ");
            int q = Integer.parseInt(sc.nextLine().trim());
            if (q <= 0) { System.out.println("Invalid qty"); continue; }
            if (p.getStock() < q) {
                System.out.println("Insufficient stock. Available: " + p.getStock());
                continue;
            }
            o.addItem(new OrderItem(p.getSku(), p.getName(), q, p.getPrice()));
            inv.reduceStock(sku, q);
            System.out.println("Added to order.");
        }
        if (o.getTotal() > 0) {
            om.placeOrder(o);
            System.out.println("Order placed. Total: ₹" + o.getTotal());
        } else {
            System.out.println("No items in order. Cancelled.");
        }
    }

    private static void viewOrders() {
        System.out.println("\nOrders:");
        for (Order o : om.listOrders()) {
            System.out.println(o.toString());
            System.out.println("----------------");
        }
    }
}
