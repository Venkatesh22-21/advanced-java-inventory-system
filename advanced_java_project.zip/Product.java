import java.io.*;
public class Product {
    private String sku;
    private String name;
    private double price;
    private int stock;

    public Product(String sku, String name, double price, int stock) {
        this.sku = sku;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public String getSku() { return sku; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getStock() { return stock; }

    public void setStock(int stock) { this.stock = stock; }

    @Override
    public String toString() {
        return sku + " | " + name + " | ₹" + price + " | Stock: " + stock;
    }

    // CSV serialization: sku,name,price,stock
    public String toCSV() {
        return sku + "," + name.replace(",", " ") + "," + price + "," + stock;
    }

    public static Product fromCSV(String line) {
        String[] parts = line.split(",");
        if (parts.length < 4) return null;
        String sku = parts[0];
        String name = parts[1];
        double price = Double.parseDouble(parts[2]);
        int stock = Integer.parseInt(parts[3]);
        return new Product(sku, name, price, stock);
    }
}
