import java.io.*;
import java.util.*;
public class Inventory {
    private Map<String, Product> products = new LinkedHashMap<>();
    private File file;

    public Inventory(String filepath) {
        this.file = new File(filepath);
        load();
    }

    public void addProduct(Product p) {
        products.put(p.getSku(), p);
        save();
    }

    public Product getProduct(String sku) {
        return products.get(sku);
    }

    public Collection<Product> listProducts() {
        return products.values();
    }

    public boolean reduceStock(String sku, int qty) {
        Product p = products.get(sku);
        if (p == null || p.getStock() < qty) return false;
        p.setStock(p.getStock() - qty);
        save();
        return true;
    }

    public void load() {
        products.clear();
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                Product p = Product.fromCSV(line);
                if (p != null) products.put(p.getSku(), p);
            }
        } catch (Exception e) {
            System.out.println("Failed to load products: " + e.getMessage());
        }
    }

    public void save() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            for (Product p : products.values()) {
                pw.println(p.toCSV());
            }
        } catch (Exception e) {
            System.out.println("Failed to save products: " + e.getMessage());
        }
    }
}
